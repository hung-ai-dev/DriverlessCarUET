
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "rs232.h"


#define BUFF_SIZE  64

int
api_uart_open();

int
api_uart_write( int cport_nr,  char* buf_send);

int
api_uart_read(int cport_nr, char *buf_recv);
