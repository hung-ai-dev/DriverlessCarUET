var group__group__advanced__objects =
[
    [ "Object: Array (Advanced)", "group__group__adv__array.html", "group__group__adv__array" ],
    [ "Object: Node (Advanced)", "group__group__adv__node.html", "group__group__adv__node" ],
    [ "Object: Delay", "group__group__delay.html", "group__group__delay" ],
    [ "Object: Kernel", "group__group__kernel.html", "group__group__kernel" ],
    [ "Object: Parameter", "group__group__parameter.html", "group__group__parameter" ]
];