var group__group__nvx__render =
[
    [ "FeatureStyle", "group__group__nvx__render.html#structnvxio_1_1Render_1_1FeatureStyle", [
      [ "color", "group__group__nvx__render.html#af5c3475096fb2868149b2b73035f0581", null ],
      [ "radius", "group__group__nvx__render.html#ac1f301ba2b904d4a71433e7870ec543a", null ]
    ] ],
    [ "Render", "classnvxio_1_1Render.html", [
      [ "CircleStyle", "classnvxio_1_1Render.html#structnvxio_1_1Render_1_1CircleStyle", [
        [ "color", "classnvxio_1_1Render.html#ab510550af699ebb884dde21805594440", null ],
        [ "thickness", "classnvxio_1_1Render.html#a2ac0a58bc1fe90d6657d8fb80be7a36d", null ]
      ] ],
      [ "DetectedObjectStyle", "classnvxio_1_1Render.html#structnvxio_1_1Render_1_1DetectedObjectStyle", [
        [ "color", "classnvxio_1_1Render.html#a023d83bb50c2e4b731fd795add3f2c93", null ],
        [ "isHalfTransparent", "classnvxio_1_1Render.html#a83bc9e6fb3c9b29a595f7a849fa5ef58", null ],
        [ "label", "classnvxio_1_1Render.html#ae4aa03efdc4ca574601eb3ef08f15959", null ],
        [ "radius", "classnvxio_1_1Render.html#a72119c0a461cc16ae6e98f2ab7b921a9", null ],
        [ "thickness", "classnvxio_1_1Render.html#acc7ea3e458c573d4f7d374eaa84a3c86", null ]
      ] ],
      [ "LineStyle", "classnvxio_1_1Render.html#structnvxio_1_1Render_1_1LineStyle", [
        [ "color", "classnvxio_1_1Render.html#a8fdfa023d7b9c12f26ad0a90e8244616", null ],
        [ "thickness", "classnvxio_1_1Render.html#a8eb96ff5d4dc7e6e0443d1e4bce14020", null ]
      ] ],
      [ "MotionFieldStyle", "classnvxio_1_1Render.html#structnvxio_1_1Render_1_1MotionFieldStyle", [
        [ "color", "classnvxio_1_1Render.html#a67f30cc03f85370a33e6b7eac4605fae", null ]
      ] ],
      [ "OnKeyboardEventCallback", "classnvxio_1_1Render.html#aea2491c1b6dcb1206c7a4324b0abc844", null ],
      [ "OnMouseEventCallback", "classnvxio_1_1Render.html#a3c88acfc869647cd685c39d337942912", null ],
      [ "MouseButtonEvent", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13", [
        [ "LeftButtonDown", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13aabf0eb8f54c63219ec24afce5b0dbaf0", null ],
        [ "LeftButtonUp", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13af367b808c21baa4410d6119bcc4466ad", null ],
        [ "MiddleButtonDown", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13a27d652a78f35c2f42e10e012e781f6ab", null ],
        [ "MiddleButtonUp", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13a72c693f4e2fa0edaf6aa5ad1c99ce7b5", null ],
        [ "RightButtonDown", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13aaf8e036d756d1aea80868859b725bcb0", null ],
        [ "RightButtonUp", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13a06c48c9b436f91f280414c18a4651591", null ],
        [ "MouseMove", "classnvxio_1_1Render.html#a533c5d650af100e8c8f7c7e3fd51cc13a7fb0760f8eaea9d50dc8b17b8aabd971", null ]
      ] ],
      [ "TargetType", "classnvxio_1_1Render.html#add92074022b692db63c91d79928647ec", [
        [ "UNKNOWN_RENDER", "classnvxio_1_1Render.html#add92074022b692db63c91d79928647eca548d6c618f8c45682f12f53d1511eeb1", null ],
        [ "WINDOW_RENDER", "classnvxio_1_1Render.html#add92074022b692db63c91d79928647eca394f5c94ebdb1b360d16f48190d2e32c", null ],
        [ "VIDEO_RENDER", "classnvxio_1_1Render.html#add92074022b692db63c91d79928647ecae09e44ae9b0a2cbe658b9a381a365f52", null ],
        [ "IMAGE_RENDER", "classnvxio_1_1Render.html#add92074022b692db63c91d79928647eca1d0831fea7bd4349e363c0480f37684e", null ]
      ] ],
      [ "~Render", "classnvxio_1_1Render.html#a2acbb70513d2e06b6e11119bdde58895", null ],
      [ "Render", "classnvxio_1_1Render.html#a19ff69e11db19cc804e4f38f20931f89", null ],
      [ "close", "classnvxio_1_1Render.html#a4d93d1db8b1d0e93c1c2ccc816dbb3b6", null ],
      [ "flush", "classnvxio_1_1Render.html#a7c595cda47658f40d33f8ad5bd09a25c", null ],
      [ "getRenderName", "classnvxio_1_1Render.html#af3f5fbd298002537731af0d3804e6e68", null ],
      [ "getTargetType", "classnvxio_1_1Render.html#a91a0f370cd80450c5b34f4300acd59b5", null ],
      [ "getViewportHeight", "classnvxio_1_1Render.html#ae54bcc9eb4c4805585a8162f3848601e", null ],
      [ "getViewportWidth", "classnvxio_1_1Render.html#a5ca7b9003d3f97a0c6a3ab484b925428", null ],
      [ "putArrows", "classnvxio_1_1Render.html#a496e6ebda2299b3308690685cc8ac2f8", null ],
      [ "putCircles", "classnvxio_1_1Render.html#a85961b4e67b10618c6a82f808d2c53eb", null ],
      [ "putConvexPolygon", "classnvxio_1_1Render.html#a1e8480ea6b5b3dc1a69ce5ce05357b0d", null ],
      [ "putFeatures", "classnvxio_1_1Render.html#a783cbdc59779eeb58ef1f01743707723", null ],
      [ "putFeatures", "classnvxio_1_1Render.html#a0f299056733b1d814fe57954b9fcc78b", null ],
      [ "putImage", "classnvxio_1_1Render.html#a12ce7c448e7c53dd5f3904a53ac0ad48", null ],
      [ "putLines", "classnvxio_1_1Render.html#afa4df1c7128e76758c0fca481e5d3a37", null ],
      [ "putMotionField", "classnvxio_1_1Render.html#ad417322ac9516b617a9567ac5690552b", null ],
      [ "putObjectLocation", "classnvxio_1_1Render.html#a3b192c4219401d5f3f0d96ff364bafaf", null ],
      [ "putTextViewport", "classnvxio_1_1Render.html#a1f4a2ca553000738efa4d2c2a6ae74be", null ],
      [ "setOnKeyboardEventCallback", "classnvxio_1_1Render.html#ae83742d270c266c7a3d41544bc3a6a01", null ],
      [ "setOnMouseEventCallback", "classnvxio_1_1Render.html#ae4e78a171992b7fd419a70b8be6b3899", null ],
      [ "renderName", "classnvxio_1_1Render.html#a78faaa6ee6c5c326ab88f97518821308", null ],
      [ "targetType", "classnvxio_1_1Render.html#ab409e119d6f2eae5ba4d3b7bca51a064", null ]
    ] ],
    [ "TextBoxStyle", "group__group__nvx__render.html#structnvxio_1_1Render_1_1TextBoxStyle", [
      [ "bgcolor", "group__group__nvx__render.html#ab18f26453fc5fc0a3c8fc570b893820a", null ],
      [ "color", "group__group__nvx__render.html#a582929e385d41c43fc9a725286338149", null ],
      [ "origin", "group__group__nvx__render.html#ad07a89a7ad4c59a30cd258c7a17d16b0", null ]
    ] ],
    [ "createDefaultRender", "group__group__nvx__render.html#ga574d69c6287504ecdf2325e5ae62f22f", null ],
    [ "createImageRender", "group__group__nvx__render.html#ga345b5b27fe4535d4ee754c81fe586c35", null ],
    [ "createVideoRender", "group__group__nvx__render.html#ga39fd25d30ab44e465fd15695ad6c23a0", null ],
    [ "createWindowRender", "group__group__nvx__render.html#ga9041e03b4086ba7c15f4e61101bdc476", null ]
];