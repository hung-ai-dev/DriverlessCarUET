var group__group__nvx__frame__source =
[
    [ "FrameSource", "classnvxio_1_1FrameSource.html", [
      [ "Parameters", "structnvxio_1_1FrameSource_1_1Parameters.html", [
        [ "Parameters", "structnvxio_1_1FrameSource_1_1Parameters.html#aba88609f4d89541c5cc71576d22c4180", null ],
        [ "format", "structnvxio_1_1FrameSource_1_1Parameters.html#a6e40cc69eb06a56885f0156150205736", null ],
        [ "fps", "structnvxio_1_1FrameSource_1_1Parameters.html#aed74e39bb5e4c8f33e4f1f7e796e31fa", null ],
        [ "frameHeight", "structnvxio_1_1FrameSource_1_1Parameters.html#a8c9fde134cb4c88b326eb5605971a702", null ],
        [ "frameWidth", "structnvxio_1_1FrameSource_1_1Parameters.html#afbca6393b5cb03e85e6bc47a6b1314dd", null ]
      ] ],
      [ "FrameStatus", "classnvxio_1_1FrameSource.html#ad18c504e17972ca351a5b2d20cec905e", [
        [ "OK", "classnvxio_1_1FrameSource.html#ad18c504e17972ca351a5b2d20cec905eaff2cbdda89092428d7d66ee70808fa80", null ],
        [ "TIMEOUT", "classnvxio_1_1FrameSource.html#ad18c504e17972ca351a5b2d20cec905ea06fe44e43c34bb3120e29606562471fc", null ],
        [ "CLOSED", "classnvxio_1_1FrameSource.html#ad18c504e17972ca351a5b2d20cec905ead1ad8f5ee95be8271252f1c79996153d", null ]
      ] ],
      [ "SourceType", "classnvxio_1_1FrameSource.html#ab1426632bdb32eade4c3286873307f41", [
        [ "UNKNOWN_SOURCE", "classnvxio_1_1FrameSource.html#ab1426632bdb32eade4c3286873307f41ae051fd868981e99e309b99c69335f5ce", null ],
        [ "SINGLE_IMAGE_SOURCE", "classnvxio_1_1FrameSource.html#ab1426632bdb32eade4c3286873307f41aa8b0ef6c7b2f690a371f983b519ee2f3", null ],
        [ "IMAGE_SEQUENCE_SOURCE", "classnvxio_1_1FrameSource.html#ab1426632bdb32eade4c3286873307f41aa5644c40b1afe9762a37faab965382c7", null ],
        [ "VIDEO_SOURCE", "classnvxio_1_1FrameSource.html#ab1426632bdb32eade4c3286873307f41ad3d8ade32443c154aee9932f0cab2eb3", null ],
        [ "CAMERA_SOURCE", "classnvxio_1_1FrameSource.html#ab1426632bdb32eade4c3286873307f41ac1ef5a7fd638ed0f0a7122c54e1d7858", null ]
      ] ],
      [ "~FrameSource", "classnvxio_1_1FrameSource.html#a40458ad842d127a2883602181a053859", null ],
      [ "FrameSource", "classnvxio_1_1FrameSource.html#a1a609c040ea6fa455c2a7b622b9eb035", null ],
      [ "close", "classnvxio_1_1FrameSource.html#a8f55bd2f3cf564fa1a8d9c25e701d123", null ],
      [ "fetch", "classnvxio_1_1FrameSource.html#a8853060d02756d018039f3f7ea60e66c", null ],
      [ "getConfiguration", "classnvxio_1_1FrameSource.html#a68ae89fb14b9bac46e83f3044ff69165", null ],
      [ "getSourceName", "classnvxio_1_1FrameSource.html#a8cfce6a5f7333357bdd34fef9c235703", null ],
      [ "getSourceType", "classnvxio_1_1FrameSource.html#afbdfa61cb912c7bf5a155f5f5f05acd9", null ],
      [ "open", "classnvxio_1_1FrameSource.html#a398f945acd97e2c7561b8c3ac05fd220", null ],
      [ "setConfiguration", "classnvxio_1_1FrameSource.html#a5f6f9c068ba335584383a86d31b71a63", null ],
      [ "sourceName", "classnvxio_1_1FrameSource.html#abfa356582d4d896cfd140a830f07a64f", null ],
      [ "sourceType", "classnvxio_1_1FrameSource.html#a910029944a9e9490f59ffb42fc168fc2", null ]
    ] ],
    [ "createDefaultFrameSource", "group__group__nvx__frame__source.html#gaaa1e074e5f3ec6d87fc1adc27ddf9156", null ],
    [ "loadImageFromFile", "group__group__nvx__frame__source.html#ga9fb8b2b9e47c8247363b1466f3e57134", null ]
];