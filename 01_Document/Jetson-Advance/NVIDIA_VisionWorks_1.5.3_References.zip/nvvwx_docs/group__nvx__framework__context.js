var group__nvx__framework__context =
[
    [ "nvx_context_attribute_e", "group__nvx__framework__context.html#gac3692f817a8279acb869f1773414d55a", [
      [ "NVX_CONTEXT_INITIAL_CUDA_DEVICE", "group__nvx__framework__context.html#ggac3692f817a8279acb869f1773414d55aaf9f3acfa1f127fa101c523f1c003b1d7", null ]
    ] ]
];