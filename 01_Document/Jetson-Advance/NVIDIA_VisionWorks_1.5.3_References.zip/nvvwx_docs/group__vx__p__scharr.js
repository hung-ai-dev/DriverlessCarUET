var group__vx__p__scharr =
[
    [ "nvxScharr3x3Node", "group__vx__p__scharr.html#gac47ab45f56db12a00cc30fdb2518fc34", null ],
    [ "nvxuScharr3x3", "group__vx__p__scharr.html#ga6513c599731d9e657d36cf21af780862", null ]
];