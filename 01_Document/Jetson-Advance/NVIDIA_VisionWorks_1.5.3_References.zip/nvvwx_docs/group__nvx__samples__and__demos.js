var group__nvx__samples__and__demos =
[
    [ "Sample and Demos User Guides", "group__nvx__samples__and__demos__user__guides.html", "group__nvx__samples__and__demos__user__guides" ],
    [ "Sample Applications", "group__nvx__samples.html", "group__nvx__samples" ],
    [ "Demo Applications", "group__nvx__demos.html", "group__nvx__demos" ]
];