var group__nvx__framework__debug__log =
[
    [ "nvx_log_zone_e", "group__nvx__framework__debug__log.html#gad4201010e2881514d1f6f6ea15da3b9c", [
      [ "NVX_LOG_ZONE_ERROR", "group__nvx__framework__debug__log.html#ggad4201010e2881514d1f6f6ea15da3b9ca9fc117887486d3844ec5f87cdf6f5e6d", null ],
      [ "NVX_LOG_ZONE_WARNING", "group__nvx__framework__debug__log.html#ggad4201010e2881514d1f6f6ea15da3b9cade4a60a2ba08b9fc1240a5099007fd5c", null ],
      [ "NVX_LOG_ZONE_API", "group__nvx__framework__debug__log.html#ggad4201010e2881514d1f6f6ea15da3b9ca9d15748eadc4a1139c35c2ea7548a356", null ],
      [ "NVX_LOG_ZONE_GRAPH", "group__nvx__framework__debug__log.html#ggad4201010e2881514d1f6f6ea15da3b9caa31f54f1933a06bbeeff30875b2e4f0b", null ],
      [ "NVX_LOG_ZONE_DATA", "group__nvx__framework__debug__log.html#ggad4201010e2881514d1f6f6ea15da3b9cadaa00211880827a5d4ce08d473d2ec4b", null ],
      [ "NVX_LOG_ZONE_MEMORY", "group__nvx__framework__debug__log.html#ggad4201010e2881514d1f6f6ea15da3b9caf0cc2d128d78bcc87fda8e0bcbd85945", null ],
      [ "NVX_LOG_ZONE_PERF", "group__nvx__framework__debug__log.html#ggad4201010e2881514d1f6f6ea15da3b9caf7d07924c1408b69b3f9d0cf41891f87", null ],
      [ "NVX_LOG_ZONE_MISC", "group__nvx__framework__debug__log.html#ggad4201010e2881514d1f6f6ea15da3b9caca8954c0714628dc5466c7594a306487", null ]
    ] ],
    [ "nvxSetLogZone", "group__nvx__framework__debug__log.html#ga85abf75da6c0a9cb28c9782c6878777f", null ]
];