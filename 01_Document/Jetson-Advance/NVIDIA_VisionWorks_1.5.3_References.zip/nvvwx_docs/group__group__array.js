var group__group__array =
[
    [ "vxArrayItem", "group__group__array.html#ga9b10bfd44f918317c122467f6e22b3ba", null ],
    [ "vxFormatArrayPointer", "group__group__array.html#ga62098c9607c75842ec82b726be02a739", null ],
    [ "vx_array", "group__group__array.html#gab1f0193f8a470dd2fe10de539a533697", null ],
    [ "vx_array_attribute_e", "group__group__array.html#gad4a2939e3d71ab3b1ae36733ab7b9511", [
      [ "VX_ARRAY_ITEMTYPE", "group__group__array.html#ggad4a2939e3d71ab3b1ae36733ab7b9511afe833292ed3f57ddde0a91d18f6f78a4", null ],
      [ "VX_ARRAY_NUMITEMS", "group__group__array.html#ggad4a2939e3d71ab3b1ae36733ab7b9511ab75da735188bc96e2eaca3fa395fac5d", null ],
      [ "VX_ARRAY_CAPACITY", "group__group__array.html#ggad4a2939e3d71ab3b1ae36733ab7b9511a037613d79c7c724208eb4c3873bbd059", null ],
      [ "VX_ARRAY_ITEMSIZE", "group__group__array.html#ggad4a2939e3d71ab3b1ae36733ab7b9511a72eddd666ec3af9cf9a9a9d6e5cc23ab", null ]
    ] ],
    [ "vxAddArrayItems", "group__group__array.html#ga4ae4a4953c224dbab68ea31b2ab1b748", null ],
    [ "vxCopyArrayRange", "group__group__array.html#ga90a35b687ec743d3d414ecdcd852759d", null ],
    [ "vxCreateArray", "group__group__array.html#gadf974c775415af0cd3c5b0f9cd6417db", null ],
    [ "vxCreateVirtualArray", "group__group__array.html#gaa9a6b28a938dc65cc9e2e079666b983e", null ],
    [ "vxMapArrayRange", "group__group__array.html#ga532c755084f03ab9089f24bae92ca8ab", null ],
    [ "vxQueryArray", "group__group__array.html#ga3275cbe5da8025a261ec6ffce137dba6", null ],
    [ "vxReleaseArray", "group__group__array.html#ga97f5e5f8ecb81fce0ae6f16836467357", null ],
    [ "vxTruncateArray", "group__group__array.html#gaa0f19ccced0a89aaaec7a3bc56faed1a", null ],
    [ "vxUnmapArrayRange", "group__group__array.html#ga5d9be9157b753e561b1a6b5d2d1c0fd4", null ]
];