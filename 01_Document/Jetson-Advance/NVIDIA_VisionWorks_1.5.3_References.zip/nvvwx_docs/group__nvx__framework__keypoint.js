var group__nvx__framework__keypoint =
[
    [ "nvx_keypointf_t", "group__nvx__framework__keypoint.html#structnvx__keypointf__t", [
      [ "error", "group__nvx__framework__keypoint.html#a7c0ce2625315728d944377507fb99a9d", null ],
      [ "orientation", "group__nvx__framework__keypoint.html#a24b768c3b16f5323bb88a7955da8a541", null ],
      [ "scale", "group__nvx__framework__keypoint.html#a952666553f040fe078f7339e51b0c02c", null ],
      [ "strength", "group__nvx__framework__keypoint.html#a140ae9a9f516a5ca446c7c5f44c4d9fd", null ],
      [ "tracking_status", "group__nvx__framework__keypoint.html#a4a88b48350c3ade73ac828fee3f66101", null ],
      [ "x", "group__nvx__framework__keypoint.html#a430958d37eae56a34c8a4c466dc61736", null ],
      [ "y", "group__nvx__framework__keypoint.html#a2265785adaeb09d10ba69bbdda74f46b", null ]
    ] ]
];