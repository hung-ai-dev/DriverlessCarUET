var group__group__vision__function__not =
[
    [ "vxNotNode", "group__group__vision__function__not.html#ga2eaea9feddc63b80e040a4b7ee66384f", null ],
    [ "vxuNot", "group__group__vision__function__not.html#ga6b5ef3481e22e78fe31a4eaa479ff8f4", null ]
];