var group__nvx__framework__basic__types =
[
    [ "NVX_LIBRARY_NVIDIA", "group__nvx__framework__basic__types.html#ga9ddf7d14736bb3fcc2cd14af1ed61d9f", null ],
    [ "nvx_enum_e", "group__nvx__framework__basic__types.html#gaffae55439ab09d6e11db67de37439197", [
      [ "NVX_ENUM_MUTABILITY", "group__nvx__framework__basic__types.html#ggaffae55439ab09d6e11db67de37439197a41254a24defc1b1243f790aa5a530d79", null ]
    ] ],
    [ "nvx_kernel_e", "group__nvx__framework__basic__types.html#ga204b4a5df2867e6f923da0ca590e9015", [
      [ "NVX_KERNEL_HARRIS_TRACK", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a316a922596b79e7f9ca2356ed23471ee", null ],
      [ "NVX_KERNEL_FAST_TRACK", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a68add8667578c6178ca6d3224d22c85a", null ],
      [ "NVX_KERNEL_FLIP_IMAGE", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a5c2bc6be03448f043c8e0f71181b7ce4", null ],
      [ "NVX_KERNEL_COPY_IMAGE", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a288ef86712a79dc08abdabe02d87fc81", null ],
      [ "NVX_KERNEL_SEMI_GLOBAL_MATCHING", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015ac39d2634e69883eea7f8034f2e167f5c", null ],
      [ "NVX_KERNEL_HOUGH_LINES", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a1bd81f95fb68d9dacc121c0008a980e7", null ],
      [ "NVX_KERNEL_HOUGH_SEGMENTS", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a3d6e356aa61d99574ff0d2f9df8bbd7d", null ],
      [ "NVX_KERNEL_HOUGH_CIRCLES", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a487eec7f57a7e44cdd59c3bec58c8fbb", null ],
      [ "NVX_KERNEL_SCHARR_3x3", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a32cb914be4d7304b9ef382af303e1972", null ],
      [ "NVX_KERNEL_LAPLACIAN_3x3", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a216659494fc723724b1bb67383061a6a", null ],
      [ "NVX_KERNEL_MEDIAN_FLOW", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015ac3fc5c82cb08ac08eab9e182da8608ac", null ],
      [ "NVX_KERNEL_STEREO_BLOCK_MATCHING", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a4ca9da1fcd445208b1b168c6c9493644", null ],
      [ "NVX_KERNEL_FIND_HOMOGRAPHY", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a8b189c359f63e75248d886196503f103", null ],
      [ "NVX_KERNEL_CREATE_MOTION_FIELD", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a81153a0c0786da63dc93149067076ed7", null ],
      [ "NVX_KERNEL_REFINE_MOTION_FIELD", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015af51eb960ae98355034fa2f9bb736b0a5", null ],
      [ "NVX_KERNEL_PARTITION_MOTION_FIELD", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015aed82237f1d31bc67611b0bf3ce5f477f", null ],
      [ "NVX_KERNEL_MULTIPLY_BY_SCALAR", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a3f0250f923eaac9cc4f452e97cb66c39", null ],
      [ "NVX_KERNEL_SGBM_COMPUTE_COST_BT", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a4055486a1e89cd019a3108dd3f3c07fe", null ],
      [ "NVX_KERNEL_SGBM_AGGREGATE_COST_SCANLINES", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015ac154f38fecf3a41182d7a6d3f474f180", null ],
      [ "NVX_KERNEL_SGBM_CONVOLVE_COST", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a4fd051547aaddbfd02715174d748d410", null ],
      [ "NVX_KERNEL_SGBM_COMPUTE_DISPARITY", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015af4b5a70d0403f19718677c5d5ca77f71", null ],
      [ "NVX_KERNEL_SGBM_COMPUTE_MODIFIED_COST_BT", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015ae20b2e79ead89f490812bf0f3960daa7", null ],
      [ "NVX_KERNEL_SGBM_FILTER_COST", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a556d6768ccb0c24d25cf08517bc6d6e0", null ],
      [ "NVX_KERNEL_SGBM_PYRAMIDAL_COST_PRIOR", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a1ea154f4c54479e0e134acf0e558b582", null ],
      [ "NVX_KERNEL_SGBM_PYRAMIDAL_DISPARITY_MERGE", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a33f79d21d5cba41e1c17fefdf1f38025", null ],
      [ "NVX_KERNEL_SGBM_CENSUS_TRANSFORM", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015af843fa87f1b8af672b67a3da0d206458", null ],
      [ "NVX_KERNEL_SGBM_COMPUTE_COST_HAMMING", "group__nvx__framework__basic__types.html#gga204b4a5df2867e6f923da0ca590e9015a9938e94a9be6e7766d00e4e76a05cb3e", null ]
    ] ],
    [ "nvx_type_e", "group__nvx__framework__basic__types.html#gabc441a216208d9ddcfbdf1506adfdf68", [
      [ "NVX_TYPE_POINT2F", "group__nvx__framework__basic__types.html#ggabc441a216208d9ddcfbdf1506adfdf68a578421663e139e7cbd5c89962f456c57", null ],
      [ "NVX_TYPE_POINT3F", "group__nvx__framework__basic__types.html#ggabc441a216208d9ddcfbdf1506adfdf68a88c59ddc4ff768204a9e213135e721dd", null ],
      [ "NVX_TYPE_POINT4F", "group__nvx__framework__basic__types.html#ggabc441a216208d9ddcfbdf1506adfdf68abf6bae00fe1fd993b42e574caff81667", null ],
      [ "NVX_TYPE_KEYPOINTF", "group__nvx__framework__basic__types.html#ggabc441a216208d9ddcfbdf1506adfdf68a8879b89fb8c5f63a9b650358a466c272", null ],
      [ "NVX_TYPE_STRUCT_MAX", "group__nvx__framework__basic__types.html#ggabc441a216208d9ddcfbdf1506adfdf68a669aaebeb0c676b0ee4807fd03aa628a", null ],
      [ "NVX_TYPE_OBJECT_MAX", "group__nvx__framework__basic__types.html#ggabc441a216208d9ddcfbdf1506adfdf68ac7262b97e3c414acbe1ef95937e2e745", null ]
    ] ]
];