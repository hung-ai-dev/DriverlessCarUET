var group__group__nvxcu__frame__source =
[
    [ "FrameSource", "classnvxcuio_1_1FrameSource.html", [
      [ "Parameters", "structnvxcuio_1_1FrameSource_1_1Parameters.html", [
        [ "Parameters", "structnvxcuio_1_1FrameSource_1_1Parameters.html#a923d762e855d75e3d57205978f225344", null ],
        [ "format", "structnvxcuio_1_1FrameSource_1_1Parameters.html#a27db20f84576a09a4e53f6295521661e", null ],
        [ "fps", "structnvxcuio_1_1FrameSource_1_1Parameters.html#ae344b88f2f5b25ecc93fae419d2098b8", null ],
        [ "frameHeight", "structnvxcuio_1_1FrameSource_1_1Parameters.html#a23333ec0d120df3dc7c11d56b69b4daa", null ],
        [ "frameWidth", "structnvxcuio_1_1FrameSource_1_1Parameters.html#addb8d1da9ae60c667cf9270b05aa975d", null ]
      ] ],
      [ "FrameStatus", "classnvxcuio_1_1FrameSource.html#a7a518d583451d31bef32c2317551cb9e", [
        [ "OK", "classnvxcuio_1_1FrameSource.html#a7a518d583451d31bef32c2317551cb9ea9716d50b230ef968e529326adbbfd127", null ],
        [ "TIMEOUT", "classnvxcuio_1_1FrameSource.html#a7a518d583451d31bef32c2317551cb9eabf0712f77b35a7a42fafe47e5540de74", null ],
        [ "CLOSED", "classnvxcuio_1_1FrameSource.html#a7a518d583451d31bef32c2317551cb9eaf9b32ccce9a59646a9cd2c3e1ec8f9e1", null ]
      ] ],
      [ "SourceType", "classnvxcuio_1_1FrameSource.html#adfe98e92dca588daa660ca21641ac46f", [
        [ "UNKNOWN_SOURCE", "classnvxcuio_1_1FrameSource.html#adfe98e92dca588daa660ca21641ac46fa80e6600fbfd85d5f7da3b703329802c3", null ],
        [ "SINGLE_IMAGE_SOURCE", "classnvxcuio_1_1FrameSource.html#adfe98e92dca588daa660ca21641ac46fac1430df59884dbe8dc9748bc0af7953b", null ],
        [ "IMAGE_SEQUENCE_SOURCE", "classnvxcuio_1_1FrameSource.html#adfe98e92dca588daa660ca21641ac46fa59234871ab2f0eee87f9a1f956b2cf43", null ],
        [ "VIDEO_SOURCE", "classnvxcuio_1_1FrameSource.html#adfe98e92dca588daa660ca21641ac46fa0adba117011b8a0f973e90d43f6d6ed3", null ],
        [ "CAMERA_SOURCE", "classnvxcuio_1_1FrameSource.html#adfe98e92dca588daa660ca21641ac46fa854118cc5363ac6e9b45f61d12ce88d6", null ]
      ] ],
      [ "~FrameSource", "classnvxcuio_1_1FrameSource.html#a3513ff01a768aa9ae9305a98ba3f01d4", null ],
      [ "FrameSource", "classnvxcuio_1_1FrameSource.html#ab264d105496d66794b9164a62de01840", null ],
      [ "close", "classnvxcuio_1_1FrameSource.html#ac356eec46806d02be727506106038222", null ],
      [ "fetch", "classnvxcuio_1_1FrameSource.html#af9e75cc48d4c89015cb1557d411543d1", null ],
      [ "getConfiguration", "classnvxcuio_1_1FrameSource.html#a6b8598dbe5b985e4ab5b28c7340f393e", null ],
      [ "getSourceName", "classnvxcuio_1_1FrameSource.html#a8a5dd695d74eac8b612b89ccc1acf0b3", null ],
      [ "getSourceType", "classnvxcuio_1_1FrameSource.html#ab36f71a2bf5a955ced6c8bc676f4a211", null ],
      [ "open", "classnvxcuio_1_1FrameSource.html#a6bce618dd373d3f97d853e4210cc5966", null ],
      [ "setConfiguration", "classnvxcuio_1_1FrameSource.html#ae639210011af41375c009b977ea106e3", null ],
      [ "sourceName", "classnvxcuio_1_1FrameSource.html#a00ed580ebdd4669c270d96aab2b9fb50", null ],
      [ "sourceType", "classnvxcuio_1_1FrameSource.html#a22c8d8b76e58264fc9156fc5a65b9dc1", null ]
    ] ],
    [ "createDefaultFrameSource", "group__group__nvxcu__frame__source.html#gab5e52741f0715dbe401930061914e6ed", null ],
    [ "loadImageFromFile", "group__group__nvxcu__frame__source.html#gae72789c575de7763def76a6c04393624", null ]
];