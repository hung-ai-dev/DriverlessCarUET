var group__group__lut =
[
    [ "vx_lut", "group__group__lut.html#ga575a2ddce2162b9ac214ca31c0981e3e", null ],
    [ "vx_lut_attribute_e", "group__group__lut.html#ga542c33297994ce6fcaaf1712541cc2a7", [
      [ "VX_LUT_TYPE", "group__group__lut.html#gga542c33297994ce6fcaaf1712541cc2a7a4a38cde417bbc1ede3a6bfef9fdbcc74", null ],
      [ "VX_LUT_COUNT", "group__group__lut.html#gga542c33297994ce6fcaaf1712541cc2a7acec0514b3d47f3e1b0e8bbdace96b12a", null ],
      [ "VX_LUT_SIZE", "group__group__lut.html#gga542c33297994ce6fcaaf1712541cc2a7a3fb902530c9bb8bfdbe73354906ef88a", null ],
      [ "VX_LUT_OFFSET", "group__group__lut.html#gga542c33297994ce6fcaaf1712541cc2a7a58b66b8a4e1a97b67a14de3e49159b30", null ]
    ] ],
    [ "vxCopyLUT", "group__group__lut.html#gaead34853c1c8a381634571c49cbd4f9a", null ],
    [ "vxCreateLUT", "group__group__lut.html#gade21f5562580768fe002bd0528b5bb35", null ],
    [ "vxMapLUT", "group__group__lut.html#ga975ee1086f915cd926f6511cfa89e000", null ],
    [ "vxQueryLUT", "group__group__lut.html#ga97c0e50ca6c4f81d25110322714f432b", null ],
    [ "vxReleaseLUT", "group__group__lut.html#ga539778ee314712f7af5d7f08c496de8c", null ],
    [ "vxUnmapLUT", "group__group__lut.html#ga6ef74c7a60e6ac6b9daed4805f603032", null ]
];