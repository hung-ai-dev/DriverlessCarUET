var group__group__pyramid =
[
    [ "VX_SCALE_PYRAMID_HALF", "group__group__pyramid.html#ga54f005b336d84c97f75fc850ab860625", null ],
    [ "VX_SCALE_PYRAMID_ORB", "group__group__pyramid.html#ga30db077cbbad64bfecdfa35d5630eea9", null ],
    [ "vx_pyramid", "group__group__pyramid.html#gad9e43dc4026a9593d63e3e9881b9c4d9", null ],
    [ "vx_pyramid_attribute_e", "group__group__pyramid.html#ga959e697be8a346cf77090cadb24dbb80", [
      [ "VX_PYRAMID_LEVELS", "group__group__pyramid.html#gga959e697be8a346cf77090cadb24dbb80affcdfbb44879028c0529733b91038ca6", null ],
      [ "VX_PYRAMID_SCALE", "group__group__pyramid.html#gga959e697be8a346cf77090cadb24dbb80a7d9e48186db43e457340b633ab8dcc8b", null ],
      [ "VX_PYRAMID_WIDTH", "group__group__pyramid.html#gga959e697be8a346cf77090cadb24dbb80ac3e794fc162370168f017333fcfc3aee", null ],
      [ "VX_PYRAMID_HEIGHT", "group__group__pyramid.html#gga959e697be8a346cf77090cadb24dbb80af056380a41cadf25dd60f69fcac56e2f", null ],
      [ "VX_PYRAMID_FORMAT", "group__group__pyramid.html#gga959e697be8a346cf77090cadb24dbb80a5f4cc8e5145c6441ffc75bb704a392f2", null ]
    ] ],
    [ "vxCreatePyramid", "group__group__pyramid.html#gafbe9699b1ca60e0c8c00af3d767da043", null ],
    [ "vxCreateVirtualPyramid", "group__group__pyramid.html#gad12c13ad56f1a9f5cdbd89091c5ac46a", null ],
    [ "vxGetPyramidLevel", "group__group__pyramid.html#gaccf509859f3f0c01a9fb3b1c034c19f9", null ],
    [ "vxQueryPyramid", "group__group__pyramid.html#ga34c57ab40a22a98bbf038e4fb841d2db", null ],
    [ "vxReleasePyramid", "group__group__pyramid.html#ga186b55fac815df8f7ab95b9ff93848fe", null ]
];