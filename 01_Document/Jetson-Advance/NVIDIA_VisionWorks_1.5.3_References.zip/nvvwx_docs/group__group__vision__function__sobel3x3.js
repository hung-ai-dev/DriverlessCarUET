var group__group__vision__function__sobel3x3 =
[
    [ "vxSobel3x3Node", "group__group__vision__function__sobel3x3.html#gafcd43da8855003037834f67be961aa81", null ],
    [ "vxuSobel3x3", "group__group__vision__function__sobel3x3.html#gab516ff90a033116e46156fad42c7f413", null ]
];