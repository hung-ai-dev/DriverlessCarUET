var group__group__vision__function__channelextract =
[
    [ "vxChannelExtractNode", "group__group__vision__function__channelextract.html#ga0c5feb26a6a958f8eb3c66e139ca0663", null ],
    [ "vxuChannelExtract", "group__group__vision__function__channelextract.html#gafcd14110125ec0217d6929ebe5406aaa", null ]
];