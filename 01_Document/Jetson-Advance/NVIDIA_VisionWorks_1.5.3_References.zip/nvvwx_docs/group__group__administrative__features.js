var group__group__administrative__features =
[
    [ "Advanced Objects", "group__group__advanced__objects.html", "group__group__advanced__objects" ],
    [ "Advanced Framework API", "group__group__advanced__framework.html", "group__group__advanced__framework" ]
];