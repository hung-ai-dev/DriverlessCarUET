var group__nvx__framework__reference =
[
    [ "nvxReleaseReferenceList", "group__nvx__framework__reference.html#ga5761fe1fd74495f1fa6d613d2321ad46", null ]
];