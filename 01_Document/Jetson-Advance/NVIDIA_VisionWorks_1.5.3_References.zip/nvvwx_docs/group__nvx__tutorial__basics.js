var group__nvx__tutorial__basics =
[
    [ "Initialization and Deinitialization", "group__nvx__tutorial__basics__1.html", null ],
    [ "Error Checking", "group__nvx__tutorial__basics__2.html", null ],
    [ "Image Data Object", "group__nvx__tutorial__basics__3.html", null ],
    [ "Single Image Processing with Immediate Mode", "group__nvx__tutorial__basics__4.html", null ],
    [ "Video Processing with Graph Mode", "group__nvx__tutorial__basics__5.html", null ],
    [ "Delay Object Usage", "group__nvx__tutorial__basics__6.html", null ]
];