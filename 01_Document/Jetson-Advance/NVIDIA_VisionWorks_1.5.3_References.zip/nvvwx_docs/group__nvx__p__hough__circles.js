var group__nvx__p__hough__circles =
[
    [ "nvxHoughCirclesNode", "group__nvx__p__hough__circles.html#gad061c3846bcf368294baafe11f32b440", null ],
    [ "nvxuHoughCircles", "group__nvx__p__hough__circles.html#gaab2d7e36221d8ee5560fc23688598821", null ]
];