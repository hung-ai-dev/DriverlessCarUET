var group__nvx__framework__cuda =
[
    [ "nvx_accessor_e", "group__nvx__framework__cuda.html#gad0ad16f2e53af988ec4247d9b2581e29", [
      [ "NVX_READ_ONLY_CUDA", "group__nvx__framework__cuda.html#ggad0ad16f2e53af988ec4247d9b2581e29aa6c35f31ea757d6e0e05e99bb79df934", null ],
      [ "NVX_WRITE_ONLY_CUDA", "group__nvx__framework__cuda.html#ggad0ad16f2e53af988ec4247d9b2581e29a323563f9bc543463402ee7a62498a13c", null ],
      [ "NVX_READ_AND_WRITE_CUDA", "group__nvx__framework__cuda.html#ggad0ad16f2e53af988ec4247d9b2581e29a6de5b6b9d87b722c5469a6e03d272ba4", null ]
    ] ],
    [ "nvx_memory_type_e", "group__nvx__framework__cuda.html#gaca75f9aaa510ac91c8c7747f3ff46e60", [
      [ "NVX_MEMORY_TYPE_CUDA", "group__nvx__framework__cuda.html#ggaca75f9aaa510ac91c8c7747f3ff46e60a3ceb7e3f613709ad7db2eedc823bea30", null ],
      [ "NVX_MEMORY_TYPE_CUDA_ARRAY", "group__nvx__framework__cuda.html#ggaca75f9aaa510ac91c8c7747f3ff46e60a03c9964f889f8745aea7e1d6b1d4d6f9", null ]
    ] ]
];