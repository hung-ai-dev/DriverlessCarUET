var group__nvx__p__flip__image =
[
    [ "nvx_flip_mode_e", "group__nvx__p__flip__image.html#gabb31442df18cc3855b60c2ea54fc0564", [
      [ "NVX_FLIP_HORIZONTAL", "group__nvx__p__flip__image.html#ggabb31442df18cc3855b60c2ea54fc0564a06ca20d48b7b7327fcf34618a8bb931c", null ],
      [ "NVX_FLIP_VERTICAL", "group__nvx__p__flip__image.html#ggabb31442df18cc3855b60c2ea54fc0564add0f6263d9fcfa52ee3ea32bd577a7ae", null ],
      [ "NVX_FLIP_BOTH", "group__nvx__p__flip__image.html#ggabb31442df18cc3855b60c2ea54fc0564a611cff1384f14175693e9f2e6a4328bf", null ]
    ] ],
    [ "nvxFlipImageNode", "group__nvx__p__flip__image.html#ga7cec3ef9007d21f8c42addb10553be9d", null ],
    [ "nvxuFlipImage", "group__nvx__p__flip__image.html#ga7cc7826dff6e2823599a5af269f4bb33", null ]
];