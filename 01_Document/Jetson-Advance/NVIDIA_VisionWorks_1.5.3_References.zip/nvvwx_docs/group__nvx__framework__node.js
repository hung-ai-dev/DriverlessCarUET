var group__nvx__framework__node =
[
    [ "nvx_node_attribute_e", "group__nvx__framework__node.html#ga2cbfc4d6c4668547eaa1e1fe64193dbc", [
      [ "NVX_NODE_CUDA_STREAM", "group__nvx__framework__node.html#gga2cbfc4d6c4668547eaa1e1fe64193dbca329989fe0a9c844332d61d624ba4dc0c", null ]
    ] ]
];