var group__group__graph__parameters =
[
    [ "vxAddParameterToGraph", "group__group__graph__parameters.html#ga0d22fac26dc5e3c168fc0056f306ff29", null ],
    [ "vxGetGraphParameterByIndex", "group__group__graph__parameters.html#ga22807a4c4759527df54523c5a53a951d", null ],
    [ "vxSetGraphParameterByIndex", "group__group__graph__parameters.html#ga376e00e31c517e283676d8f7e74a2cc4", null ]
];