var group__group__scalar =
[
    [ "vx_scalar", "group__group__scalar.html#ga1bf12c9f0e72ed39970212b04148788d", null ],
    [ "vx_scalar_attribute_e", "group__group__scalar.html#gac8804b87294558898585e744d454ced9", [
      [ "VX_SCALAR_TYPE", "group__group__scalar.html#ggac8804b87294558898585e744d454ced9a6092df8afe0ba6a11777966c13251a6d", null ]
    ] ],
    [ "vxCopyScalar", "group__group__scalar.html#gac0d4fdb4d6cc4f86840cb90392681cd1", null ],
    [ "vxCreateScalar", "group__group__scalar.html#ga53933b83d7efdbad0a55b742a6316318", null ],
    [ "vxQueryScalar", "group__group__scalar.html#gab14b9a4edfccd5746873375b78914d9a", null ],
    [ "vxReleaseScalar", "group__group__scalar.html#gaf54f1457fd608849a408e4bbbddf587d", null ]
];