var group__nvx__framework__timer =
[
    [ "Timer", "classnvx_1_1Timer.html", [
      [ "Timer", "classnvx_1_1Timer.html#a036aa427073439cc5676e23ef6d018ad", null ],
      [ "~Timer", "classnvx_1_1Timer.html#abce87321203756718f2db800bfce6673", null ],
      [ "tic", "classnvx_1_1Timer.html#a8a24202f58f50bd82fa92f01d598b875", null ],
      [ "toc", "classnvx_1_1Timer.html#ae3b4b1326ae9d23babd224f7277b1b7a", null ]
    ] ],
    [ "NVX_TIMER", "group__nvx__framework__timer.html#ga3ff313267bc19a75bf325435c510c032", null ],
    [ "NVX_TIMEROFF", "group__nvx__framework__timer.html#gadde9482fb6ded777449c6ac8f30a6079", null ]
];