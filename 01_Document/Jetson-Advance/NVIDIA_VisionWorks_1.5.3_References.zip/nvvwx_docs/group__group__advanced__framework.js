var group__group__advanced__framework =
[
    [ "Framework: Node Callbacks", "group__group__node__callback.html", "group__group__node__callback" ],
    [ "Framework: Performance Measurement", "group__group__performance.html", "group__group__performance" ],
    [ "Framework: Log", "group__group__log.html", "group__group__log" ],
    [ "Framework: Hints", "group__group__hint.html", "group__group__hint" ],
    [ "Framework: Directives", "group__group__directive.html", "group__group__directive" ],
    [ "Framework: User Kernels", "group__group__user__kernels.html", "group__group__user__kernels" ],
    [ "Framework: Graph Parameters", "group__group__graph__parameters.html", "group__group__graph__parameters" ]
];