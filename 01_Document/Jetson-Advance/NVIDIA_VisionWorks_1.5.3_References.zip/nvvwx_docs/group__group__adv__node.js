var group__group__adv__node =
[
    [ "Node: Border Modes", "group__group__borders.html", "group__group__borders" ],
    [ "vxCreateGenericNode", "group__group__adv__node.html#gab76f82d9aff214db0806b67bb0fb6e77", null ]
];