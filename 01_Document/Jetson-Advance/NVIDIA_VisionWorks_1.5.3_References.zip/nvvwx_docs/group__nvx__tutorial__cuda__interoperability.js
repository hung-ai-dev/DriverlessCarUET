var group__nvx__tutorial__cuda__interoperability =
[
    [ "Process Image with CUDA Kernel", "group__nvx__tutorial__cuda__interoperability__1.html", null ],
    [ "Process Array with CUBLAS Library", "group__nvx__tutorial__cuda__interoperability__2.html", null ],
    [ "Import NV12 Image from CUDA Address Space", "group__nvx__tutorial__cuda__interoperability__3.html", null ]
];