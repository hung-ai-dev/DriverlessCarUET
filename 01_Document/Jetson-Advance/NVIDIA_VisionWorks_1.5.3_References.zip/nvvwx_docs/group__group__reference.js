var group__group__reference =
[
    [ "VX_MAX_REFERENCE_NAME", "group__group__reference.html#ga8a36adc5433cc3b2d575766bad7f399d", null ],
    [ "vx_reference", "group__group__reference.html#ga1a95c3bf180e49d4d1ecd64cb35f45a3", null ],
    [ "vx_reference_attribute_e", "group__group__reference.html#ga769da45f9a00160000c8982549eea4e2", [
      [ "VX_REF_ATTRIBUTE_COUNT", "group__group__reference.html#gga769da45f9a00160000c8982549eea4e2a1a42e0b79fcb1aa9586c28f30d4d9579", null ],
      [ "VX_REF_ATTRIBUTE_TYPE", "group__group__reference.html#gga769da45f9a00160000c8982549eea4e2ae55e53544fdc30742055277971fdf120", null ],
      [ "VX_REF_ATTRIBUTE_NAME", "group__group__reference.html#gga769da45f9a00160000c8982549eea4e2a6eff840bc3f294a3b7f1490d3972bcf7", null ]
    ] ],
    [ "vxQueryReference", "group__group__reference.html#ga90f1230bf615e3e2d7e618cab1e2d6dc", null ],
    [ "vxReleaseReference", "group__group__reference.html#gadd23893e169c3da18b5618b671c3e3f2", null ],
    [ "vxRetainReference", "group__group__reference.html#ga7c1adb9ab5c95f42d89cd02b44b9c729", null ],
    [ "vxSetReferenceName", "group__group__reference.html#ga37a9e5c435def91352d2bd7574375210", null ]
];