var group__group__nvxio__utility =
[
    [ "ContextGuard", "structnvxio_1_1ContextGuard.html", [
      [ "ContextGuard", "structnvxio_1_1ContextGuard.html#a6d6eb353d0398b8b8831b08e82901d65", null ],
      [ "ContextGuard", "structnvxio_1_1ContextGuard.html#a8177c76e94e35f02554e7867a25cd6af", null ],
      [ "~ContextGuard", "structnvxio_1_1ContextGuard.html#add5d69708fee5b8282ce507ce6cec8dc", null ],
      [ "operator vx_context", "structnvxio_1_1ContextGuard.html#a583d17551dc36ae6174af0e564576044", null ],
      [ "operator vx_reference", "structnvxio_1_1ContextGuard.html#a46fa9d25ca76842cf687f684de61e32e", null ],
      [ "operator=", "structnvxio_1_1ContextGuard.html#ac080c04e901ee619e6b562ab8187f677", null ]
    ] ],
    [ "NVXIO_ASSERT", "group__group__nvxio__utility.html#ga9388b80d29765e17c51187a72f56ff31", null ],
    [ "NVXIO_CHECK_REFERENCE", "group__group__nvxio__utility.html#ga7f3ab2c266c15a57159a01642dc00a1b", null ],
    [ "NVXIO_CUDA_SAFE_CALL", "group__group__nvxio__utility.html#ga1b5be9fcc5e14eca81baa5fedcc316e9", null ],
    [ "NVXIO_SAFE_CALL", "group__group__nvxio__utility.html#ga36dbb5d0f6453cacb2e3640d785ca2d8", null ],
    [ "NVXIO_THROW_EXCEPTION", "group__group__nvxio__utility.html#ga269dfc49fc0d81c4a925b673f844ecd8", null ],
    [ "checkIfContextIsValid", "group__group__nvxio__utility.html#gaa7672746e24f3c74ab0e65f88360289d", null ],
    [ "dimOf", "group__group__nvxio__utility.html#gaa9907f22e9144aebdbc5ef2b004fb284", null ],
    [ "getSupportedFeatures", "group__group__nvxio__utility.html#ga5769e1b792f567bc826ce7e42d86a9f5", null ],
    [ "makeUP", "group__group__nvxio__utility.html#gaa6e4df730b69e1f850bf98053f26e459", null ],
    [ "printPerf", "group__group__nvxio__utility.html#ga81241b2530c776b39bf1a4ada661c3d2", null ],
    [ "printPerf", "group__group__nvxio__utility.html#ga2543eba66152193e3b2da5a03d40b2f4", null ],
    [ "stdoutLogCallback", "group__group__nvxio__utility.html#ga67996a2fc1c20bb2941fa648dde03a72", null ],
    [ "PI", "group__group__nvxio__utility.html#ga0cf46afa3f5bb37faa5c0fcaac15ec98", null ],
    [ "PI_F", "group__group__nvxio__utility.html#ga3a94b6855833ab790466e8399b1d05c8", null ]
];