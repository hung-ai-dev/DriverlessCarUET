var group__nvx__tutorial__cuda__api =
[
    [ "Data Object Creation", "group__nvx__tutorial__cuda__api__1.html", null ],
    [ "Primitives Usage", "group__nvx__tutorial__cuda__api__2.html", null ]
];