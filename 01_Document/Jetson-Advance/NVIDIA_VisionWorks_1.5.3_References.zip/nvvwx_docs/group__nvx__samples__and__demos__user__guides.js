var group__nvx__samples__and__demos__user__guides =
[
    [ "Linux: Building and Running Samples and Demos", "group__nvx__sample__building__linux.html", null ],
    [ "Windows: Building and Running Samples and Demos", "group__nvx__sample__building__windows.html", null ]
];