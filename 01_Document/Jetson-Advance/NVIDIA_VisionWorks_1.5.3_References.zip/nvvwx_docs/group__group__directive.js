var group__group__directive =
[
    [ "vx_directive_e", "group__group__directive.html#gaae805d69ffdb9dfdb1f3cbc75f4cd18b", [
      [ "VX_DIRECTIVE_DISABLE_LOGGING", "group__group__directive.html#ggaae805d69ffdb9dfdb1f3cbc75f4cd18ba532d849a99dc82934e92a2ce06fe4d3e", null ],
      [ "VX_DIRECTIVE_ENABLE_LOGGING", "group__group__directive.html#ggaae805d69ffdb9dfdb1f3cbc75f4cd18ba8c2254d25a1863cddf545a24c65ca2c0", null ],
      [ "VX_DIRECTIVE_DISABLE_PERFORMANCE", "group__group__directive.html#ggaae805d69ffdb9dfdb1f3cbc75f4cd18baea2702ef92ddc2690908b788b9c124a7", null ],
      [ "VX_DIRECTIVE_ENABLE_PERFORMANCE", "group__group__directive.html#ggaae805d69ffdb9dfdb1f3cbc75f4cd18babe6db8b6c39169d5b031acb542653508", null ]
    ] ],
    [ "vxDirective", "group__group__directive.html#ga053bbc2470a8df7d94c42d694aed1eff", null ]
];