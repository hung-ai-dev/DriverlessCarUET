var group__nvx__p__medianflow =
[
    [ "nvxMedianFlowNode", "group__nvx__p__medianflow.html#ga4ec6963f5b4b81c029e94f6368cf884b", null ],
    [ "nvxuMedianFlow", "group__nvx__p__medianflow.html#gafe28bdba08ea15bb7fa5e25c93f09c45", null ]
];