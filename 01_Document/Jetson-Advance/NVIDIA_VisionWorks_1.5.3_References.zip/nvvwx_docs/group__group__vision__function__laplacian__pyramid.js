var group__group__vision__function__laplacian__pyramid =
[
    [ "vxLaplacianPyramidNode", "group__group__vision__function__laplacian__pyramid.html#ga63ea13fe79157f1d2f1c871a62f12a0f", null ],
    [ "vxuLaplacianPyramid", "group__group__vision__function__laplacian__pyramid.html#gacd2f8c7d1751622496dde00e0de757b7", null ]
];