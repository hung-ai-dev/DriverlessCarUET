var group__group__vision__function__canny =
[
    [ "vx_norm_type_e", "group__group__vision__function__canny.html#gaabfffda8bd2d6cd1458d6e7db006615a", [
      [ "VX_NORM_L1", "group__group__vision__function__canny.html#ggaabfffda8bd2d6cd1458d6e7db006615aa0246f733180e0c5d661aec1f241794b3", null ],
      [ "VX_NORM_L2", "group__group__vision__function__canny.html#ggaabfffda8bd2d6cd1458d6e7db006615aaaa71c24d95873e690ffb7a9552bf76df", null ]
    ] ],
    [ "vxCannyEdgeDetectorNode", "group__group__vision__function__canny.html#gab20e1350dcdf517a12c472ddfb9ac68d", null ],
    [ "vxuCannyEdgeDetector", "group__group__vision__function__canny.html#gad040e9dc21fb8aa085ba2e49671ef6e8", null ]
];