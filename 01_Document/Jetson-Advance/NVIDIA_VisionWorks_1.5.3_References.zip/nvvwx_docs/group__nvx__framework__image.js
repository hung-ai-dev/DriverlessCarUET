var group__nvx__framework__image =
[
    [ "nvx_cuarray_handle_2d_t", "group__nvx__framework__image.html#structnvx__cuarray__handle__2d__t", [
      [ "array", "group__nvx__framework__image.html#a2bb7b92625816cdc239f0cde60c65b55", null ],
      [ "offset_x", "group__nvx__framework__image.html#ab00a5be1db8cac09be54046ee739f2cd", null ],
      [ "offset_y", "group__nvx__framework__image.html#aa8e01fe7b116bce8c08229751dbd1557", null ]
    ] ],
    [ "nvx_df_image_e", "group__nvx__framework__image.html#gada4ec9582cbbc67a7673ce5791d1b5c2", [
      [ "NVX_DF_IMAGE_F32", "group__nvx__framework__image.html#ggada4ec9582cbbc67a7673ce5791d1b5c2ab5fa91f6819e90421cf9b59ee5c702c7", null ],
      [ "NVX_DF_IMAGE_2F32", "group__nvx__framework__image.html#ggada4ec9582cbbc67a7673ce5791d1b5c2a266c6bfc32396474d5ac58b66f42e2c6", null ],
      [ "NVX_DF_IMAGE_2S16", "group__nvx__framework__image.html#ggada4ec9582cbbc67a7673ce5791d1b5c2a7fec235d884fede396f9670d3e976818", null ],
      [ "NVX_DF_IMAGE_RGB16", "group__nvx__framework__image.html#ggada4ec9582cbbc67a7673ce5791d1b5c2ace1d3fb70b76830bffde7d067bd4072d", null ]
    ] ]
];