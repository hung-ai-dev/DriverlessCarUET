var group__group__vision__function__or =
[
    [ "vxOrNode", "group__group__vision__function__or.html#gadff7e1e499e2c556f88b398deab01ded", null ],
    [ "vxuOr", "group__group__vision__function__or.html#ga258747f2baae870ebeb8981e84650b84", null ]
];