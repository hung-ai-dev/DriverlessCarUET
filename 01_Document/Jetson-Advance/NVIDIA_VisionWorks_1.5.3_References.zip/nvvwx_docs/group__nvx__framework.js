var group__nvx__framework =
[
    [ "Version Information", "group__nvx__framework__version.html", "group__nvx__framework__version" ],
    [ "Debug Log", "group__nvx__framework__debug__log.html", "group__nvx__framework__debug__log" ],
    [ "Resource Control", "group__nvx__framework__resource__control.html", "group__nvx__framework__resource__control" ],
    [ "CUDA Interoperability", "group__nvx__framework__cuda.html", "group__nvx__framework__cuda" ],
    [ "Error Management Extensions", "group__nvx__framework__error__management.html", "group__nvx__framework__error__management" ],
    [ "Reference Extensions", "group__nvx__framework__reference.html", "group__nvx__framework__reference" ],
    [ "Context Object Extensions", "group__nvx__framework__context.html", "group__nvx__framework__context" ],
    [ "Graph Object Extensions", "group__nvx__framework__graph.html", "group__nvx__framework__graph" ],
    [ "Delay Object Extensions", "group__nvx__framework__delay.html", null ],
    [ "Kernel Object Extensions", "group__nvx__framework__kernel.html", "group__nvx__framework__kernel" ],
    [ "Types Extensions", "group__nvx__framework__basic__types.html", "group__nvx__framework__basic__types" ],
    [ "Point Coordinate Types", "group__nvx__framework__point.html", "group__nvx__framework__point" ],
    [ "KeyPoint Types", "group__nvx__framework__keypoint.html", "group__nvx__framework__keypoint" ],
    [ "Image Data Object Extensions", "group__nvx__framework__image.html", "group__nvx__framework__image" ],
    [ "Array Data Object Extensions", "group__nvx__framework__array.html", null ],
    [ "Distribution Data Object Extensions", "group__nvx__framework__distribution.html", null ],
    [ "LUT Data Object Extensions", "group__nvx__framework__lut.html", null ],
    [ "Matrix Data Object Extensions", "group__nvx__framework__matrix.html", null ],
    [ "Remap Data Object Extensions", "group__nvx__framework__remap.html", "group__nvx__framework__remap" ],
    [ "Timer", "group__nvx__framework__timer.html", "group__nvx__framework__timer" ],
    [ "Node Object Extensions", "group__nvx__framework__node.html", "group__nvx__framework__node" ]
];