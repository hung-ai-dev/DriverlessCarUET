var group__group__nvxcu__render =
[
    [ "Render", "classnvxcuio_1_1Render.html", [
      [ "CircleStyle", "classnvxcuio_1_1Render.html#structnvxcuio_1_1Render_1_1CircleStyle", [
        [ "color", "classnvxcuio_1_1Render.html#ad33d3dcb77cc6fb0ef7f973506fddf3c", null ],
        [ "thickness", "classnvxcuio_1_1Render.html#a5c4be1d0ce6bd0dcd42347447fffccbf", null ]
      ] ],
      [ "DetectedObjectStyle", "classnvxcuio_1_1Render.html#structnvxcuio_1_1Render_1_1DetectedObjectStyle", [
        [ "color", "classnvxcuio_1_1Render.html#a1d070ecd04cc20f1489df0e2420a3b69", null ],
        [ "isHalfTransparent", "classnvxcuio_1_1Render.html#a3b657db4c1c233eee333b0dcd6889bf6", null ],
        [ "label", "classnvxcuio_1_1Render.html#a9f9fbc886d81eace5fbe2c60383e37f0", null ],
        [ "radius", "classnvxcuio_1_1Render.html#a328bcf04727e8547ec510ecdbff173eb", null ],
        [ "thickness", "classnvxcuio_1_1Render.html#a5cf2641887a257ae73cefef9c6a1ec78", null ]
      ] ],
      [ "FeatureStyle", "classnvxcuio_1_1Render.html#structnvxcuio_1_1Render_1_1FeatureStyle", [
        [ "color", "classnvxcuio_1_1Render.html#a56823b3c0e2e6ec340efff965bcb3d5c", null ],
        [ "radius", "classnvxcuio_1_1Render.html#a3be945579df38fcc597db31cbbee1edf", null ]
      ] ],
      [ "LineStyle", "classnvxcuio_1_1Render.html#structnvxcuio_1_1Render_1_1LineStyle", [
        [ "color", "classnvxcuio_1_1Render.html#a9a00d339736242f23463eeafe3a0dd6e", null ],
        [ "thickness", "classnvxcuio_1_1Render.html#ade39c29083246efa5be8af09020ff5c4", null ]
      ] ],
      [ "MotionFieldStyle", "classnvxcuio_1_1Render.html#structnvxcuio_1_1Render_1_1MotionFieldStyle", [
        [ "color", "classnvxcuio_1_1Render.html#a3f5340b9f1f5e7cbe31c529ae6428df2", null ]
      ] ],
      [ "TextBoxStyle", "classnvxcuio_1_1Render.html#structnvxcuio_1_1Render_1_1TextBoxStyle", [
        [ "bgcolor", "classnvxcuio_1_1Render.html#a21833dfe86184880d5d224611219f272", null ],
        [ "color", "classnvxcuio_1_1Render.html#a02dc272329727f1c30818b2fa0c7c59e", null ],
        [ "origin", "classnvxcuio_1_1Render.html#afa0f7095de431af5f589507420f89d3a", null ]
      ] ],
      [ "OnKeyboardEventCallback", "classnvxcuio_1_1Render.html#aa77ba26153d49899c9163fb287e0c9e7", null ],
      [ "OnMouseEventCallback", "classnvxcuio_1_1Render.html#abe05e3529415433d0cad6b86fc5d1cf9", null ],
      [ "MouseButtonEvent", "classnvxcuio_1_1Render.html#aabe36328809c224997112ccc1fc65494", [
        [ "LeftButtonDown", "classnvxcuio_1_1Render.html#aabe36328809c224997112ccc1fc65494af4f84a6b706bd86f79a72b17ebd80e23", null ],
        [ "LeftButtonUp", "classnvxcuio_1_1Render.html#aabe36328809c224997112ccc1fc65494a8f6e5ef9ab9e4da1a2029ef5be402ba8", null ],
        [ "MiddleButtonDown", "classnvxcuio_1_1Render.html#aabe36328809c224997112ccc1fc65494a1c8db2626bdc475d2e880e98a6754f0a", null ],
        [ "MiddleButtonUp", "classnvxcuio_1_1Render.html#aabe36328809c224997112ccc1fc65494a34c983157017d1b83023921d803d0c33", null ],
        [ "RightButtonDown", "classnvxcuio_1_1Render.html#aabe36328809c224997112ccc1fc65494a6b016c374305985a33f6bc8a44880191", null ],
        [ "RightButtonUp", "classnvxcuio_1_1Render.html#aabe36328809c224997112ccc1fc65494aee91663091dfe60ab755175c795e3456", null ],
        [ "MouseMove", "classnvxcuio_1_1Render.html#aabe36328809c224997112ccc1fc65494a599efaffd9e40ec173c31588dbd6f00f", null ]
      ] ],
      [ "TargetType", "classnvxcuio_1_1Render.html#a5d36c35f2c796ddec2f595701ee2f9e0", [
        [ "UNKNOWN_RENDER", "classnvxcuio_1_1Render.html#a5d36c35f2c796ddec2f595701ee2f9e0a449140c3867af0dbb83716afa32339d9", null ],
        [ "WINDOW_RENDER", "classnvxcuio_1_1Render.html#a5d36c35f2c796ddec2f595701ee2f9e0ae14998a7045a043768c93995269486e6", null ],
        [ "VIDEO_RENDER", "classnvxcuio_1_1Render.html#a5d36c35f2c796ddec2f595701ee2f9e0a3de21787dafb22ad0bdd2684073110c2", null ],
        [ "IMAGE_RENDER", "classnvxcuio_1_1Render.html#a5d36c35f2c796ddec2f595701ee2f9e0adae68031127c65172693161a6bbe00de", null ]
      ] ],
      [ "~Render", "classnvxcuio_1_1Render.html#aa2e8aa6df5424e55bfce247944a207c6", null ],
      [ "Render", "classnvxcuio_1_1Render.html#aa9ce7ddb952064ac9b2c35ef8751fe1a", null ],
      [ "close", "classnvxcuio_1_1Render.html#acd0808f4d3baaff5555842eac2bbefb4", null ],
      [ "flush", "classnvxcuio_1_1Render.html#a96cd02a966c0373ec9a180535021fed1", null ],
      [ "getRenderName", "classnvxcuio_1_1Render.html#a41d82c1676ff44932ed8a86dd9aaecd2", null ],
      [ "getTargetType", "classnvxcuio_1_1Render.html#a7a3bb67e9a210c96232a77c1b5fd73cb", null ],
      [ "getViewportHeight", "classnvxcuio_1_1Render.html#a4badfebd395a50f5ee671be0482a0783", null ],
      [ "getViewportWidth", "classnvxcuio_1_1Render.html#a3397cc7abde1b9eb27ec61cf8f63f873", null ],
      [ "putArrows", "classnvxcuio_1_1Render.html#aa5bd72a7648c2f92004978a0bf815046", null ],
      [ "putCircles", "classnvxcuio_1_1Render.html#a3687aab1cfe7e391d06e6b665ef1297e", null ],
      [ "putConvexPolygon", "classnvxcuio_1_1Render.html#a786dc8423cef56817bde2619a6c0901c", null ],
      [ "putFeatures", "classnvxcuio_1_1Render.html#a1cb44ebe029c12d250007f073ef34129", null ],
      [ "putFeatures", "classnvxcuio_1_1Render.html#a110579427e9133ee814009cd71666f70", null ],
      [ "putImage", "classnvxcuio_1_1Render.html#abd4de6aea07933220fa64ce45de07e74", null ],
      [ "putLines", "classnvxcuio_1_1Render.html#adbbb171cdc34db5876ce7370715c2d14", null ],
      [ "putMotionField", "classnvxcuio_1_1Render.html#a34def61f1c0697435ad4fcc723da39d0", null ],
      [ "putObjectLocation", "classnvxcuio_1_1Render.html#a15b93e83262e267cf6c546d4e13f795a", null ],
      [ "putTextViewport", "classnvxcuio_1_1Render.html#a4a182a691e54796f7e4f0f90a69e8984", null ],
      [ "setOnKeyboardEventCallback", "classnvxcuio_1_1Render.html#af70d860414b4d4f020dd700c04375c0b", null ],
      [ "setOnMouseEventCallback", "classnvxcuio_1_1Render.html#ad48a1ba18f1923f6c53b320fbd02806b", null ],
      [ "renderName", "classnvxcuio_1_1Render.html#a5eb2cb43fe0b99316a4d17251ad80b2f", null ],
      [ "targetType", "classnvxcuio_1_1Render.html#abd5e149fb1a15254c90a48648739cf73", null ]
    ] ],
    [ "createDefaultRender", "group__group__nvxcu__render.html#gae825a82d60d5ab06ef72d3162211c78c", null ],
    [ "createImageRender", "group__group__nvxcu__render.html#ga11cf98c1f921cb32d948365d5d8e0555", null ],
    [ "createVideoRender", "group__group__nvxcu__render.html#ga69caa8bd09359e002d0f1fd5db3c30c4", null ],
    [ "createWindowRender", "group__group__nvxcu__render.html#ga4df1cb7003e2d24103872bdcf2fb4f66", null ]
];