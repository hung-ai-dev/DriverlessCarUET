var group__group__vision__function__integral__image =
[
    [ "vxIntegralImageNode", "group__group__vision__function__integral__image.html#gade1bda2e08ee2f21d7c46e04371df4a0", null ],
    [ "vxuIntegralImage", "group__group__vision__function__integral__image.html#ga76a93256e72200f75dec5bc1b9bc3767", null ]
];