var group__nvx__framework__point =
[
    [ "nvx_point2f_t", "group__nvx__framework__point.html#structnvx__point2f__t", [
      [ "x", "group__nvx__framework__point.html#a6649a13002c969266ebc3614f66b1074", null ],
      [ "y", "group__nvx__framework__point.html#a59d64d7706caeaba177289c0383e6ca6", null ]
    ] ],
    [ "nvx_point3f_t", "group__nvx__framework__point.html#structnvx__point3f__t", [
      [ "x", "group__nvx__framework__point.html#a05c30dffe2ced8b653f9e8adbe1e169a", null ],
      [ "y", "group__nvx__framework__point.html#a10a00444ab3f1af1da29b8efe5f40c96", null ],
      [ "z", "group__nvx__framework__point.html#a2a8badc1b1b4c2fdeea40673189683c3", null ]
    ] ],
    [ "nvx_point4f_t", "group__nvx__framework__point.html#structnvx__point4f__t", [
      [ "w", "group__nvx__framework__point.html#a108c5413c5a3c3ae79b1bd84dbf2bc4c", null ],
      [ "x", "group__nvx__framework__point.html#a12bfc5ff37233fb035067baa33a3218b", null ],
      [ "y", "group__nvx__framework__point.html#ae84e05319adaa7fc5596cb2280032e9b", null ],
      [ "z", "group__nvx__framework__point.html#aef502cd947cbc5b508876bd93058c2f9", null ]
    ] ]
];