var group__nvx__framework__resource__control =
[
    [ "nvx_target_e", "group__nvx__framework__resource__control.html#ga6da39dfe9a933f146ae395f72bd445ad", [
      [ "NVX_TARGET_CPU", "group__nvx__framework__resource__control.html#gga6da39dfe9a933f146ae395f72bd445ada02c8737aced544d259ec5ae807c3ef99", null ],
      [ "NVX_TARGET_GPU", "group__nvx__framework__resource__control.html#gga6da39dfe9a933f146ae395f72bd445adaaac5672bdc343a46e09992646a553cec", null ]
    ] ]
];