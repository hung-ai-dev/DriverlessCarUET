var group__nvx__samples =
[
    [ "OpenCV and NPP Interop Sample App", "group__nvx__sample__opencv__npp__interop.html", null ],
    [ "OpenGL Interop Sample App", "group__vwx__sample__opengl__interop.html", null ],
    [ "Video Playback Sample App", "group__vwx__sample__player.html", null ],
    [ "(L4T R24) NVIDIA GStreamer Camera Capture Sample App", "group__vwx__sample__nvcamera__capture.html", null ]
];