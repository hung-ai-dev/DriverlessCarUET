var group__group__node =
[
    [ "vx_node", "group__group__node.html#ga7f1b5d91fac63093ee3a77e87d942f96", null ],
    [ "vx_node_attribute_e", "group__group__node.html#ga6698e2a55aa6d7fd5c45e746a0d640b9", [
      [ "VX_NODE_STATUS", "group__group__node.html#gga6698e2a55aa6d7fd5c45e746a0d640b9a318524d89292e1a5cfb53e4f8e058f5a", null ],
      [ "VX_NODE_PERFORMANCE", "group__group__node.html#gga6698e2a55aa6d7fd5c45e746a0d640b9a7a44562437b6453af5b81e61db6e4455", null ],
      [ "VX_NODE_BORDER", "group__group__node.html#gga6698e2a55aa6d7fd5c45e746a0d640b9a8ab2bf9651a379fad8decf0db5d56f8c", null ],
      [ "VX_NODE_LOCAL_DATA_SIZE", "group__group__node.html#gga6698e2a55aa6d7fd5c45e746a0d640b9a5c9c48a8fdb29091d7d8a24c63e1f906", null ],
      [ "VX_NODE_LOCAL_DATA_PTR", "group__group__node.html#gga6698e2a55aa6d7fd5c45e746a0d640b9a98f3ac748f36322215fae4ac0deb27af", null ],
      [ "VX_NODE_PARAMETERS", "group__group__node.html#gga6698e2a55aa6d7fd5c45e746a0d640b9a320af83374fdedbd4a82da1869b922d5", null ],
      [ "VX_NODE_IS_REPLICATED", "group__group__node.html#gga6698e2a55aa6d7fd5c45e746a0d640b9a5e5d42c18129e3cdac3f45cdff95b9e8", null ],
      [ "VX_NODE_REPLICATE_FLAGS", "group__group__node.html#gga6698e2a55aa6d7fd5c45e746a0d640b9af11c001527b12c28251c1a830ee8e699", null ],
      [ "VX_NODE_VALID_RECT_RESET", "group__group__node.html#gga6698e2a55aa6d7fd5c45e746a0d640b9aa674356b35e4bd1b12a433abdd71cd00", null ]
    ] ],
    [ "vxQueryNode", "group__group__node.html#gac7d60a2cde3f9833725f345e5c5d185f", null ],
    [ "vxReleaseNode", "group__group__node.html#ga9a9611c3512e1c311ae0ea2fcdeefc07", null ],
    [ "vxRemoveNode", "group__group__node.html#gac56f7baf342c4269e1ce8bb0c90a5796", null ],
    [ "vxReplicateNode", "group__group__node.html#ga873198f07077015c0f60a66399b1cdf9", null ],
    [ "vxSetNodeAttribute", "group__group__node.html#gad5a8c201296752904d3c5a679320b478", null ],
    [ "vxSetNodeTarget", "group__group__node.html#ga7409f4d86e22259caae9c0d42b18cbd9", null ]
];