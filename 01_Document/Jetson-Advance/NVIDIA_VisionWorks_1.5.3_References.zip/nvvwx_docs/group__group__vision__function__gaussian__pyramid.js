var group__group__vision__function__gaussian__pyramid =
[
    [ "vxGaussianPyramidNode", "group__group__vision__function__gaussian__pyramid.html#ga16899c2fb9dd0c7ed86f66002e5b7d85", null ],
    [ "vxuGaussianPyramid", "group__group__vision__function__gaussian__pyramid.html#ga10a546830a4c013f595a1328a019563a", null ]
];