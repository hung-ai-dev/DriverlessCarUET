var group__group__object__array =
[
    [ "vx_object_array", "group__group__object__array.html#ga31a0de03c8cbf474afab6efb7bcffddb", null ],
    [ "vx_object_array_attribute_e", "group__group__object__array.html#ga77518448bc4d2d157b73defcc2cac9b9", [
      [ "VX_OBJECT_ARRAY_ITEMTYPE", "group__group__object__array.html#gga77518448bc4d2d157b73defcc2cac9b9a1182311f349e73b8e5d5b343ce6654b4", null ],
      [ "VX_OBJECT_ARRAY_NUMITEMS", "group__group__object__array.html#gga77518448bc4d2d157b73defcc2cac9b9a9fd280c529fa57498c11013a8ee55b67", null ]
    ] ],
    [ "vxCreateObjectArray", "group__group__object__array.html#ga283fc2b5e0c56d323d7deadfe4f62bb9", null ],
    [ "vxCreateVirtualObjectArray", "group__group__object__array.html#ga343356eaeaaa8d24e121a3c397163246", null ],
    [ "vxGetObjectArrayItem", "group__group__object__array.html#ga55cdf3d80a55136be8f5067e3dc965ed", null ],
    [ "vxQueryObjectArray", "group__group__object__array.html#ga846a3a3b3919b77e8afbbb5e08624f51", null ],
    [ "vxReleaseObjectArray", "group__group__object__array.html#gaf5a969fc84032d9ea176f2b835f15a5f", null ]
];