var group__nvx__external__links =
[
    [ "NVIDIA CUDA Resources", "group__nv__cuda__docs__all.html", "group__nv__cuda__docs__all" ],
    [ "NVIDIA Jetson TK1 Documentation", "group__nv__jetson__tk1.html", "group__nv__jetson__tk1" ],
    [ "NVIDIA Jetson TX1 Documentation", "group__nv__jetson__tx1.html", "group__nv__jetson__tx1" ],
    [ "EGL API Documentation", "group__egl__api.html", "group__egl__api" ]
];